-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 30, 2019 at 06:55 AM
-- Server version: 5.7.26
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pleto`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `status`, `date_time`) VALUES
(1, 'nitin', 'nitin@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1, '2019-07-30 06:49:58'),
(2, 'sachin', 'sachin@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1, '2019-07-30 06:51:15');

-- --------------------------------------------------------

--
-- Table structure for table `users_blog`
--

DROP TABLE IF EXISTS `users_blog`;
CREATE TABLE IF NOT EXISTS `users_blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `blog_description` text NOT NULL,
  `is_shared` int(1) NOT NULL DEFAULT '0',
  `comments` text,
  `blog_status` int(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`blog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_blog`
--

INSERT INTO `users_blog` (`blog_id`, `user_id`, `blog_description`, `is_shared`, `comments`, `blog_status`, `created_at`) VALUES
(1, 1, 'This is nitin first blog', 0, NULL, 1, '2019-07-30 12:20:34'),
(2, 1, 'This is nitin Second blog', 0, NULL, 1, '2019-07-30 12:20:46'),
(3, 2, 'This is nitin Second blog', 1, 'sssssssss', 1, '2019-07-30 12:25:16');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
