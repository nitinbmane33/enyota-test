<div id="container">
<?php
if($this->uri->segment(2)=='' || $this->session->userdata('name')==$this->uri->segment(2)){?>
	<h1>Welcome to Blog</h1>
					<div class="in forms">
						<form id="blog_form" name="blog_form" method="post" action="<?php echo base_url();?>add-blog">
						<div class="form-group">
				        <label for="email">Blog Description:</label>
								<textarea name="blog_description" rows="5" required class="form-control" id="blog_description"></textarea>
				    </div>
						<button type="submit" class="btn btn-primary">Submit</button>
						</form>
<?php } ?>

	<h1>Welcome to Our Blog</h1>

		<?php if(count($arr_blog['blog'])>0){
		foreach($arr_blog['blog'] as $entry){ ?>
    <div class="card">
      <ul class="list-group list-group-flush">
        <li class="list-group-item"><h3><?php echo $entry['blog_description']; ?></h3>
					<?php if($this->uri->segment(2)=='' || $this->session->userdata('name')==$this->uri->segment(2)){?>
					<?php } else {?>
				<button type="button" class="btn btn-info btn-lg myblog" data-id="<?php echo $entry['blog_id'];?>" data-toggle="modal" data-target="#myModal">Share</button>
			<?php } ?>
			</li>
      </ul>
    </div>
	<?php }
	}else{
		echo "<li class='list-group-item'>No record founds.</li>";
	} ?>

	<h1>Shared Blogs</h1>

	 <?php if(count($arr_blog['shared_blog'])>0){
		foreach($arr_blog['shared_blog'] as $sentry){ ?>
    <div class="card">
      <ul class="list-group list-group-flush">
        <li class="list-group-item"><h3><?php echo $sentry['blog_description']; ?></h3>
					<h5><?php echo $sentry['comments']; ?></h5>
				</li>
      </ul>
    </div>
	<?php }
	}else{
		echo "<li class='list-group-item'>No record founds.</li>";
	} ?>
	</div>
</div>

<!-- Modal content-->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
				  <h4 class="modal-title">Comment and Share</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
				<form id="comment_form" name="comment_form" method="post" action="<?php echo base_url();?>add-comment">
					<div class="form-group">
							<label for="email">Blog Comment:</label>
							<textarea name="blog_comments" rows="5" required class="form-control" id="blog_comments"></textarea>
							<input type="hidden" name="blog_id" id="blog_id" value=""/>
					</div>
					<button type="submit" class="btn btn-success">Submit</button>
					<button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
				</form>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<script>
$(document).on("click", ".myblog", function () {
     var myBlogId = $(this).data('id');
     $(".modal-body #blog_id").val( myBlogId );
});
</script>
