<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<br />
<h3>Welcome User, You are successfully logged in. </h3>
<br />
<div class="row">
    <div class="col-sm-3">
        <a class="btn btn-success" href="<?php echo base_url().'blogs';?>"> View Blogs</a>
    </div>
		<div class="col-sm-3">
        <a class="btn btn-danger" href="<?php echo base_url().'logout';?>">Logout</a>
    </div>

</div>
