<?php

class Register_Model extends CI_Model{
    public function addUser($data){
        //get the data from controller and insert into the table 'users'
        return $this->db->insert('users', $data);
    }
}
