<?php

class Login_Model extends CI_Model {

    public function checkLogin($email, $password) {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get();
        return $query->result_array();
    }
}
