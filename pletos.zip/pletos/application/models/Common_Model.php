<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Common_Model extends CI_Model {

    public function getRecords($condition = '', $table='') {
          $this->db->select('*');
          $this->db->from($table);
          if ($condition != '')
              $this->db->where($condition);

          $query = $this->db->get();
          return $query->result_array();
      }

      public function getUsersAllBlogs($condition = '') {
        $this->db->select('*');
        $this->db->from('users_blog');
        if ($condition != ''){
            $this->db->where($condition);
            $this->db->where('is_shared', 0);
          }
        $this->db->order_by("blog_id","desc");
        $query = $this->db->get();
        $data['blog'] = $query->result_array();

        $this->db->select('*');
        $this->db->from('users_blog');
        if ($condition != ''){
            $this->db->where($condition);
            $this->db->where('is_shared', 1);
          }
        $this->db->order_by("blog_id","desc");
        $query = $this->db->get();
        $data['shared_blog'] = $query->result_array();
        return $data;
    }

    public function insertData($insertData, $table_name) {
        $this->db->insert($table_name, $insertData);
        return $this->db->insert_id();
    }
}
