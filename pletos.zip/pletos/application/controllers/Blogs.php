<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogs extends CI_Controller {

	 public function __construct() {
        parent::__construct();
        $this->load->model('common_model');
    }

    public function getBlogs($name='') {

	      $data['arr_blog'] = array();
        if($name!=''){
          $conditions = array('name'=>$name);
          $user_detail = $this->common_model->getRecords($conditions,$table='users');
          if(!empty($user_detail)){
            $condition = array('user_id'=>$user_detail[0]['user_id']);
            $data['arr_blog'] = $this->common_model->getUsersAllBlogs($condition);
          }else{
							redirect(base_url() . 'blogs');
					}
        }else{
          $condition = array('user_id'=>$this->session->userdata('user_id'));
          $data['arr_blog'] = $this->common_model->getUsersAllBlogs($condition);
        }
        $this->load->view('header');
        $this->load->view('blog', $data);
        $this->load->view('footer');
    }

		public function addBlog() {

			if ($this->input->post()) {
					$insertData = array('user_id'=>$this->session->userdata('user_id'),
					'blog_description' => $this->input->post('blog_description'),
					'is_shared'=> '0',
					'blog_status'=> '1');
					$last_insert_id = $this->common_model->insertData($insertData, 'users_blog');
					redirect(base_url() . 'blogs');
				}
				$this->load->view('header');
				$this->load->view('blog', $data);
				$this->load->view('footer');
		}

		public function shareBlogComment() {

			if ($this->input->post()) {

				$conditions = array('blog_id'=>$this->input->post('blog_id'));
				$blog_detail = $this->common_model->getRecords($conditions, $table='users_blog');

					$insertData = array('user_id'=>$this->session->userdata('user_id'),
					'blog_description' => $blog_detail[0]['blog_description'],
					'is_shared'=> '1',
					'blog_status'=> '1',
					'comments' => $this->input->post('blog_comments'));
					$last_insert_id = $this->common_model->insertData($insertData, 'users_blog');
					redirect(base_url() . 'blogs');
				}

		}
}
