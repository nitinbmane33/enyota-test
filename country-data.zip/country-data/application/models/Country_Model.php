<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Country_Model extends CI_Model {

    public function getAllCountries($condition = '') {
        $this->db->select('*');
        $this->db->from('nm_country');
        if ($condition != '')
            $this->db->where($condition);

        $query = $this->db->get();
        return $query->result_array();
    }
    public function getRecords($table,$condition = '') {
        $this->db->select('*');
        $this->db->from($table);
        if ($condition != '')
            $this->db->where($condition);

        $query = $this->db->get();
        return $query->result_array();
    }

    public function getFormDataByCountry($condition = '') {
        $this->db->select('*');
        $this->db->from('nm_country_field_info as tcf');
        $this->db->join('nm_form_fields as tf', 'tf.field_id = tcf.field_id', 'inner');
        if ($condition != '')
            $this->db->where($condition);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function insertData($insertData, $table_name) {
        $this->db->insert($table_name, $insertData);
        return $this->db->insert_id();
    }

    public function getCountryInformation($condition = '') {
        $this->db->select('*');
        $this->db->from('nm_country_temp as ttd');
        $this->db->join('nm_country as tc', 'tc.country_id = ttd.country_id_fk', 'inner');
        $this->db->join('nm_form_fields_data as dd', 'dd.temp_id_fk = ttd.temp_id', 'inner');
        $this->db->join('nm_form_fields as tcc', 'tcc.field_id = dd.field_id_fk', 'inner');
        if ($condition != '')
            $this->db->where($condition);

        $query = $this->db->get();
        return $query->result_array();
    }
}
