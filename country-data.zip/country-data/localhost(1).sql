-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 14, 2017 at 03:08 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--
CREATE DATABASE `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE IF NOT EXISTS `tbl_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`country_id`, `country_name`) VALUES
(1, 'India'),
(2, 'USA'),
(3, 'UK');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country_fields`
--

CREATE TABLE IF NOT EXISTS `tbl_country_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_country_fields`
--

INSERT INTO `tbl_country_fields` (`id`, `country_id`, `field_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 6),
(4, 1, 8),
(5, 2, 1),
(6, 2, 2),
(7, 2, 7),
(8, 2, 8),
(9, 3, 2),
(10, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fields`
--

CREATE TABLE IF NOT EXISTS `tbl_fields` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `field_name` varchar(255) NOT NULL,
  `fields_names` varchar(255) NOT NULL,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_fields`
--

INSERT INTO `tbl_fields` (`field_id`, `field_name`, `fields_names`) VALUES
(1, 'contact name', 'contact_name'),
(2, 'street', 'street'),
(3, 'number', 'number'),
(4, 'street 2', 'street_two'),
(5, 'state', 'state'),
(6, 'zip', 'zip'),
(7, 'city', 'city'),
(8, 'country name', 'country_name');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fields_data`
--

CREATE TABLE IF NOT EXISTS `tbl_fields_data` (
  `field_data_id` int(11) NOT NULL AUTO_INCREMENT,
  `temp_id_fk` int(11) NOT NULL,
  `field_id_fk` int(11) NOT NULL,
  `field_data` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`field_data_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `tbl_fields_data`
--

INSERT INTO `tbl_fields_data` (`field_data_id`, `temp_id_fk`, `field_id_fk`, `field_data`) VALUES
(1, 1, 1, 'Suraj'),
(2, 1, 2, 'Somnath'),
(3, 1, 6, '121212'),
(4, 1, 8, 'INDIA'),
(5, 2, 2, 'Somnath'),
(6, 2, 3, '1236543'),
(7, 3, 1, 'Swapnil'),
(8, 3, 2, 'Somnath'),
(9, 3, 7, 'Pune'),
(10, 3, 8, 'INDAI'),
(11, 4, 1, 'swap'),
(12, 4, 2, 'stree'),
(13, 4, 6, '1234'),
(14, 4, 8, 'cnt name'),
(15, 5, 2, 'strrr'),
(16, 5, 3, '12333'),
(17, 6, 1, 'swapnil'),
(18, 6, 2, 'viman nagar'),
(19, 6, 6, '123321'),
(20, 6, 8, 'ind'),
(21, 7, 1, 'Suraj Tupe'),
(22, 7, 2, 'Somnath Nager Road'),
(23, 7, 7, 'Pune'),
(24, 7, 8, 'USA'),
(25, 8, 1, 'Suraj'),
(26, 8, 2, 'Somnath'),
(27, 8, 6, '123321'),
(28, 8, 8, 'INDIA'),
(29, 9, 2, 'Somnath Nager Road'),
(30, 9, 3, '1236543');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_temp_data`
--

CREATE TABLE IF NOT EXISTS `tbl_temp_data` (
  `temp_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`temp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_temp_data`
--

INSERT INTO `tbl_temp_data` (`temp_id`, `country_id_fk`) VALUES
(1, 1),
(2, 3),
(3, 2),
(4, 1),
(5, 3),
(6, 1),
(7, 2),
(8, 1),
(9, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_views`
--

CREATE TABLE IF NOT EXISTS `tbl_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id_fk` int(11) NOT NULL,
  `view_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_views`
--

INSERT INTO `tbl_views` (`id`, `country_id_fk`, `view_content`) VALUES
(1, 1, '<contact_name>,\r\n<street>,<zip>\r\n<country_name>'),
(2, 2, '<contact_name>,\r\n<street>,<city>\r\n<country_name>'),
(3, 3, '<street>,<number>');
