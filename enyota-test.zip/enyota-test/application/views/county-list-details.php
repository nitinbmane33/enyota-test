<?php
echo nl2br($template);

?>